package com.aziz.demosec.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "pharmacies")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Pharmacy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;
    private String address;
    private Double locationLat;
    private Double locationLng;
    private String phoneNumber;
    private String email;
}