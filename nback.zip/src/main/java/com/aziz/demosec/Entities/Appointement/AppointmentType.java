package com.aziz.demosec.Entities.Appointement;

public enum AppointmentType {
    ONLINE,
    IN_PERSON
}
