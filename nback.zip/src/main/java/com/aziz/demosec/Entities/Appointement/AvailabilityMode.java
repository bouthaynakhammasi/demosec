package com.aziz.demosec.Entities.Appointement;

public enum AvailabilityMode {
    ONLINE,
    w
}