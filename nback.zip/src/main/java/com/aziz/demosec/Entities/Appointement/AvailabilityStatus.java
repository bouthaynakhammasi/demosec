package com.aziz.demosec.Entities.Appointement;

public enum AvailabilityStatus {
    AVAILABLE,
    BOOKED,
    BLOCKED
}