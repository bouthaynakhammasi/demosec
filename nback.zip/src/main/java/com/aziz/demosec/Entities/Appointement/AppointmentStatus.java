package com.aziz.demosec.Entities.Appointement;

public enum AppointmentStatus {
    BOOKED,
    CANCELLED,
    COMPLETED,
    RESCHEDULED
}