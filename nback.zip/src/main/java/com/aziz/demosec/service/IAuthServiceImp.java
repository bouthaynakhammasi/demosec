package com.aziz.demosec.service;

import com.aziz.demosec.Entities.Patient;
import com.aziz.demosec.domain.Role;
import com.aziz.demosec.domain.User;
import com.aziz.demosec.dto.AuthResponse;
import com.aziz.demosec.dto.LoginRequest;
import com.aziz.demosec.dto.RegisterRequest;
import com.aziz.demosec.repository.PatientRepository;
import com.aziz.demosec.repository.UserRepository;
import com.aziz.demosec.security.CustomUserDetailsService;
import com.aziz.demosec.security.jwt.JwtService;

import lombok.RequiredArgsConstructor;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class IAuthServiceImp implements IAuthService {

    private final UserRepository userRepository;
    private final PatientRepository patientRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final CustomUserDetailsService userDetailsService;
    private final JwtService jwtService;

    @Override
    public User register(RegisterRequest req) {

        if (req.email() == null || req.email().isBlank())
            throw new IllegalArgumentException("Email required");

        if (req.password() == null || req.password().length() < 8)
            throw new IllegalArgumentException("Password must contain at least 8 characters");

        if (req.role() == null)
            throw new IllegalArgumentException("Role required");

        if (userRepository.findByEmail(req.email()).isPresent())
            throw new IllegalArgumentException("Email already used");

        // =========================
        // CAS PATIENT
        // =========================
        if (req.role() == Role.PATIENT) {

            Patient patient = new Patient();
            patient.setFullName(req.fullName() == null ? "Not Available" : req.fullName());
            patient.setEmail(req.email());
            patient.setPassword(passwordEncoder.encode(req.password()));
            patient.setRole(Role.PATIENT);
            patient.setPhone(req.phone());
            patient.setBirthDate(req.birthDate());

            patient.setGender(req.gender());
            patient.setBloodType(req.bloodType());
            patient.setEmergencyContactName(req.emergencyContactName());
            patient.setEmergencyContactPhone(req.emergencyContactPhone());

            // ✅ NOUVEAUX CHAMPS AJOUTÉS
            patient.setChronicDiseases(req.chronicDiseases());
            patient.setDrugAllergies(req.drugAllergies());
            patient.setHereditaryDiseases(req.hereditaryDiseases());

            patient.setEnabled(true);

            return patientRepository.save(patient);
        }

        // =========================
        // CAS DES ROLES SPECIFIQUES ET USER DE BASE
        // =========================
        switch (req.role()) {
            case DOCTOR -> {
                com.aziz.demosec.Entities.Doctor doctor = new com.aziz.demosec.Entities.Doctor();
                doctor.setFullName(req.fullName() == null ? "Not Available" : req.fullName());
                doctor.setEmail(req.email());
                doctor.setPassword(passwordEncoder.encode(req.password()));
                doctor.setRole(Role.DOCTOR);
                doctor.setPhone(req.phone());
                doctor.setBirthDate(req.birthDate());
                doctor.setEnabled(true);
                doctor.setProfileCompleted(false);
                doctor.setLicenseNumber("PENDING"); // Must not be null
                return userRepository.save(doctor);
            }
            case NUTRITIONIST -> {
                com.aziz.demosec.Entities.Nutritionist n = new com.aziz.demosec.Entities.Nutritionist();
                n.setFullName(req.fullName() == null ? "Not Available" : req.fullName());
                n.setEmail(req.email());
                n.setPassword(passwordEncoder.encode(req.password()));
                n.setRole(Role.NUTRITIONIST);
                n.setPhone(req.phone());
                n.setBirthDate(req.birthDate());
                n.setEnabled(true);
                n.setProfileCompleted(false);
                return userRepository.save(n);
            }
            case PHARMACIST -> {
                com.aziz.demosec.Entities.Pharmacist p = new com.aziz.demosec.Entities.Pharmacist();
                p.setFullName(req.fullName() == null ? "Not Available" : req.fullName());
                p.setEmail(req.email());
                p.setPassword(passwordEncoder.encode(req.password()));
                p.setRole(Role.PHARMACIST);
                p.setPhone(req.phone());
                p.setBirthDate(req.birthDate());
                p.setEnabled(true);
                p.setProfileCompleted(false);
                return userRepository.save(p);
            }
            case LABORATORYSAFF -> {
                com.aziz.demosec.Entities.LaboratoryStaff l = new com.aziz.demosec.Entities.LaboratoryStaff();
                l.setFullName(req.fullName() == null ? "Not Available" : req.fullName());
                l.setEmail(req.email());
                l.setPassword(passwordEncoder.encode(req.password()));
                l.setRole(Role.LABORATORYSAFF);
                l.setPhone(req.phone());
                l.setBirthDate(req.birthDate());
                l.setEnabled(true);
                l.setProfileCompleted(false);
                return userRepository.save(l);
            }
            case HOME_CARE_PROVIDER -> {
                User u = User.builder()
                        .fullName(req.fullName() == null ? "Not Available" : req.fullName())
                        .email(req.email())
                        .password(passwordEncoder.encode(req.password()))
                        .role(req.role())
                        .phone(req.phone())
                        .birthDate(req.birthDate())
                        .enabled(true)
                        .profileCompleted(false)
                        .build();
                return userRepository.save(u);
            }
            default -> {
                User u = User.builder()
                        .fullName(req.fullName() == null ? "Not Available" : req.fullName())
                        .email(req.email())
                        .password(passwordEncoder.encode(req.password()))
                        .role(req.role())
                        .phone(req.phone())
                        .birthDate(req.birthDate())
                        .enabled(true)
                        .profileCompleted(true) // Visitors/Admins don't have secondary profile completing phase
                        .build();
                return userRepository.save(u);
            }
        }
    }

    @Override
    public AuthResponse login(LoginRequest req) {

        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(req.email(), req.password())
        );

        UserDetails userDetails = userDetailsService.loadUserByUsername(req.email());

        String role = userDetails.getAuthorities().stream()
                .findFirst()
                .map(GrantedAuthority::getAuthority)
                .orElse("ROLE_VISITOR");

        String token = jwtService.generateToken(userDetails);

        User user = userRepository.findByEmail(req.email())
                .orElseThrow(() -> new jakarta.persistence.EntityNotFoundException("User not found"));

        return new AuthResponse(token, userDetails.getUsername(), role, user.isProfileCompleted());
    }
}