package com.aziz.demosec.repository;

import com.aziz.demosec.Entities.Appointement.CalendarAvailability;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CalendarAvailabilityRepository extends JpaRepository<CalendarAvailability, Long> {
    List<CalendarAvailability> findByCalendar_Provider_Id(Long providerId);
}