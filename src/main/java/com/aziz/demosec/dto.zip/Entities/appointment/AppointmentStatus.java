package com.aziz.demosec.Entities.appointment;

public enum AppointmentStatus {
    BOOKED,
    CANCELLED,
    COMPLETED,
    RESCHEDULED
}
