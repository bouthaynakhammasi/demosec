package com.aziz.demosec.service;

import com.aziz.demosec.Entities.appointment.Appointment;
import com.aziz.demosec.Entities.appointment.AppointmentStatus;
import com.aziz.demosec.Entities.appointment.Mode;
import com.aziz.demosec.Mapper.AppointmentMapper;
import com.aziz.demosec.domain.User;
import com.aziz.demosec.Entities.Doctor;
import com.aziz.demosec.dto.AppointmentDTO;
import com.aziz.demosec.dto.AppointmentRequest;
import com.aziz.demosec.dto.AppointmentResponse;
import com.aziz.demosec.dto.RescheduleRequest;
import com.aziz.demosec.repository.AppointmentRepository;
import com.aziz.demosec.repository.DoctorRepository;
import com.aziz.demosec.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AppointmentService implements IAppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final UserRepository userRepository;
    private final DoctorRepository doctorRepository;
    private final AppointmentMapper appointmentMapper;

    @Override
    @Transactional
    public AppointmentResponse bookAppointment(Long patientId, AppointmentRequest request) {
        User patient = userRepository.findById(patientId)
                .orElseThrow(() -> new EntityNotFoundException("Patient not found"));

        Long doctorId = request.getDoctorId() != null ? request.getDoctorId() : request.getProviderId();
        User provider = userRepository.findById(doctorId)
                .orElseThrow(() -> new EntityNotFoundException("Provider not found"));
        
        LocalDateTime start = LocalDateTime.of(LocalDate.parse(request.getDate()), LocalTime.parse(request.getStartTime()));
        LocalDateTime end = LocalDateTime.of(LocalDate.parse(request.getDate()), LocalTime.parse(request.getEndTime()));
        Mode mode = Mode.valueOf(request.getMode());

        String meetingLink = null;
        String visitAddress = null;
        
        if (mode == Mode.ONLINE) {
            meetingLink = "https://meet.jit.si/" + UUID.randomUUID().toString();
        } else if (mode == Mode.IN_PERSON) {
            // Find address from provider if available
            // For now we use the notes or a placeholder
            visitAddress = "Medical Center"; 
        }

        Appointment appointment = Appointment.builder()
                .patientId(patient.getId())
                .patient(patient)
                .doctorId(provider.getId())
                .doctor(provider)
                .providerId(provider.getId())
                .provider(provider)
                .startTime(start)
                .endTime(end)
                .status(AppointmentStatus.BOOKED)
                .meetingLink(meetingLink)
                .visitAddress(visitAddress)
                .patientNotes(request.getNotes())
                .build();

        return appointmentMapper.toDto(appointmentRepository.save(appointment));
    }

    @Override
    @Transactional
    public AppointmentResponse completeAppointment(Long appointmentId, String providerNotes) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new EntityNotFoundException("Appointment not found"));

        appointment.setStatus(AppointmentStatus.COMPLETED);
        appointment.setCompletedAt(LocalDateTime.now());
        appointment.setProviderNotes(providerNotes);

        return appointmentMapper.toDto(appointmentRepository.save(appointment));
    }

    @Override
    @Transactional
    public AppointmentResponse cancelAppointment(Long appointmentId, Long userId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new EntityNotFoundException("Appointment not found"));

        if (appointment.getStatus() != AppointmentStatus.BOOKED) {
            throw new IllegalStateException("Only BOOKED appointments can be cancelled");
        }

        appointment.setStatus(AppointmentStatus.CANCELLED);
        appointment.setCancelledAt(LocalDateTime.now());

        return appointmentMapper.toDto(appointmentRepository.save(appointment));
    }

    @Override
    @Transactional
    public AppointmentResponse rescheduleAppointment(Long oldAppointmentId, RescheduleRequest request, Long userId) {
        Appointment oldAppointment = appointmentRepository.findById(oldAppointmentId)
                .orElseThrow(() -> new EntityNotFoundException("Old Appointment not found"));

        if (oldAppointment.getStatus() != AppointmentStatus.BOOKED) {
            throw new IllegalStateException("Only BOOKED appointments can be rescheduled");
        }

        oldAppointment.setStatus(AppointmentStatus.RESCHEDULED);

        AppointmentRequest newRequest = AppointmentRequest.builder()
                .providerId(request.getNewProviderId() != null ? request.getNewProviderId() : oldAppointment.getProviderId())
                .date(request.getNewDate())
                .startTime(request.getNewStartTime())
                .endTime(request.getNewEndTime())
                .mode(request.getNewMode())
                .notes(oldAppointment.getPatientNotes())
                .build();

        return bookAppointment(oldAppointment.getPatientId(), newRequest);
    }

    @Override
    @Transactional(readOnly = true)
    public AppointmentResponse getAppointmentById(Long id) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Appointment not found"));
        return appointmentMapper.toDto(appointment);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppointmentResponse> getAppointments(Long providerId, Long patientId, AppointmentStatus status, LocalDateTime from, LocalDateTime to) {
        List<Appointment> results;
        
        if (patientId != null) {
            results = appointmentRepository.findByPatientId(patientId);
        } else if (providerId != null) {
            results = appointmentRepository.findByDoctorId(providerId);
        } else {
            results = appointmentRepository.findAll();
        }

        if (status != null) {
            results = results.stream()
                    .filter(a -> a.getStatus() == status)
                    .collect(Collectors.toList());
        }

        if (from != null && to != null) {
            results = results.stream()
                    .filter(a -> {
                        LocalDateTime start = a.getStartTime();
                        return (start != null) && (start.isEqual(from) || start.isAfter(from)) && 
                               (start.isEqual(to) || start.isBefore(to));
                    })
                    .collect(Collectors.toList());
        }

        return results.stream()
                .map(appointmentMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppointmentDTO> getPatientAppointments(Long patientId) {
        return appointmentRepository.findByPatientId(patientId)
                .stream()
                .map(appt -> {
                    AppointmentDTO dto = new AppointmentDTO();
                    dto.setId(appt.getId());
                    if (appt.getStartTime() != null) {
                        dto.setDate(appt.getStartTime().toLocalDate().toString());
                        dto.setStartTime(appt.getStartTime().toLocalTime().toString());
                    }
                    if (appt.getEndTime() != null) {
                        dto.setEndTime(appt.getEndTime().toLocalTime().toString());
                    }
                    if (appt.getStatus() != null) {
                        dto.setStatus(appt.getStatus().name());
                    }
                    if (appt.getPatientNotes() != null) {
                        dto.setNotes(appt.getPatientNotes());
                    }
                    // Extract meeting/mode logic if mode exists in Appointment, else we guess
                    // By checking how appointment is built, we have Mode? Actually Appointment entity doesn't have mode, it has meetingLink/visitAddress.
                    if (appt.getMeetingLink() != null) {
                        dto.setMode("ONLINE");
                        dto.setMeetingLink(appt.getMeetingLink());
                    } else if (appt.getVisitAddress() != null) {
                        dto.setMode("IN_PERSON");
                    } else {
                        dto.setMode("IN_PERSON");
                    }

                    if (appt.getPatient() != null) {
                        dto.setPatientName(appt.getPatient().getFullName());
                    } else {
                        userRepository.findById(appt.getPatientId()).ifPresent(p -> dto.setPatientName(p.getFullName()));
                    }

                    dto.setDoctorId(appt.getDoctorId());

                    User doctor = userRepository.findById(appt.getDoctorId()).orElse(null);
                    if (doctor != null) {
                        dto.setDoctorName(doctor.getFullName());
                        Doctor doctorProfile = doctorRepository.findById(appt.getDoctorId()).orElse(null);
                        if (doctorProfile != null) {
                            dto.setDoctorSpecialty(doctorProfile.getSpecialty());
                            if (doctorProfile.getClinic() != null) {
                                dto.setClinicName(doctorProfile.getClinic().getName());
                                dto.setClinicAddress(doctorProfile.getClinic().getAddress() != null ? doctorProfile.getClinic().getAddress() : "");
                            }
                        }
                    }
                    return dto;
                })
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppointmentResponse> getDoctorAppointmentsByDate(Long doctorId, String date) {
        LocalDate localDate = LocalDate.parse(date);
        LocalDateTime startOfDay = localDate.atStartOfDay();
        LocalDateTime endOfDay = localDate.atTime(LocalTime.MAX);

        return appointmentRepository.findByDoctorIdAndStartTimeBetween(doctorId, startOfDay, endOfDay).stream()
                .map(appointmentMapper::toDto)
                .collect(Collectors.toList());
    }
}
